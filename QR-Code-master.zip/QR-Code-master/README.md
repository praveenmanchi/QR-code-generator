# QR-Code App
QR code Genrator and Reader Using Javascript

# QR Code Generation

![QR Code Generation](./img/1.png)

# QR Code Reader 

![QR Code Generation](./img/2.png)
